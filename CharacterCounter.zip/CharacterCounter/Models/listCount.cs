﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CharacterCounter.Models
{
    public class listCounts
    {    
            public char Character { get; set; }
            public int Count { get; set; }
    }
}
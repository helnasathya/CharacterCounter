﻿using CharacterCounter.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;

namespace CharacterCounter.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "", "" };
        }

        // GET api/values/5
        public List<listCounts> Get(string id)
        {
            List<string> countList = new List<string>();
            var list = new List<listCounts>();
            string text = id;


            StringBuilder sb = new StringBuilder();
            foreach (char c in text)
            {
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_')
                {
                    sb.Append(c);
                }
            }
            var inpuString = sb.ToString();

            if (!String.IsNullOrEmpty(inpuString))
            {
                inpuString = inpuString.Replace(" ", string.Empty);
                while (inpuString.Length > 0)
                {
                    int count = 0;
                    for (int j = 0; j < inpuString.Length; j++)
                    {
                        if (inpuString[0] == inpuString[j])
                        {
                            count++;
                        }
                    }
                    int len = 0;
                    list.Add(new listCounts { Character = inpuString[len], Count = count });
                    len++;
                    inpuString = inpuString.Replace(inpuString[0].ToString(), string.Empty);
                }
            }

            return list;
        }

        // POST api/values
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
